package com.datco.conversor

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val content = findViewById<View>(R.id.splashContent)
        val footer = findViewById<View>(R.id.splashFooter)

        content.scaleX = 0.4f
        content.scaleY = 0.4f
        content.alpha = 0f
        footer.alpha = 0f

        // 1) Entrada con zoom desde chico y rebote
        content.animate()
            .scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(900)
            .setInterpolator(OvershootInterpolator(1.4f))
            .withEndAction {
                // 2) Zoom lento mientras se mantiene
                content.animate()
                    .scaleX(1.12f).scaleY(1.12f)
                    .setDuration(700)
                    .setInterpolator(DecelerateInterpolator())
                    .withEndAction {
                        // 3) Zoom final hacia adelante y salida
                        content.animate()
                            .scaleX(2.2f).scaleY(2.2f).alpha(0f)
                            .setDuration(450)
                            .setInterpolator(AccelerateInterpolator())
                            .withEndAction { irAlInicio() }
                            .start()
                        footer.animate().alpha(0f).setDuration(300).start()
                    }
                    .start()
            }
            .start()

        footer.animate().alpha(1f).setStartDelay(500).setDuration(600).start()
    }

    private fun irAlInicio() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}
