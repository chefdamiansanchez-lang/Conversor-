package com.datco.conversor

data class Unidad(val nombre: String, val simbolo: String, val factor: Double)

class Categoria(
    val nombre: String,
    val unidades: List<Unidad>,
    val esTemperatura: Boolean = false
) {
    fun convertir(valor: Double, desde: Int, hasta: Int): Double {
        if (esTemperatura) {
            val celsius = when (desde) {
                0 -> valor
                1 -> (valor - 32.0) * 5.0 / 9.0
                else -> valor - 273.15
            }
            return when (hasta) {
                0 -> celsius
                1 -> celsius * 9.0 / 5.0 + 32.0
                else -> celsius + 273.15
            }
        }
        return valor * unidades[desde].factor / unidades[hasta].factor
    }
}

object Datos {
    val categorias: List<Categoria> = listOf(
        Categoria("Longitud", listOf(
            Unidad("Metro", "m", 1.0),
            Unidad("Kilómetro", "km", 1000.0),
            Unidad("Centímetro", "cm", 0.01),
            Unidad("Milímetro", "mm", 0.001),
            Unidad("Milla", "mi", 1609.344),
            Unidad("Yarda", "yd", 0.9144),
            Unidad("Pie", "ft", 0.3048),
            Unidad("Pulgada", "in", 0.0254)
        )),
        Categoria("Masa", listOf(
            Unidad("Kilogramo", "kg", 1.0),
            Unidad("Gramo", "g", 0.001),
            Unidad("Miligramo", "mg", 0.000001),
            Unidad("Tonelada", "t", 1000.0),
            Unidad("Libra", "lb", 0.45359237),
            Unidad("Onza", "oz", 0.028349523125)
        )),
        Categoria("Temperatura", listOf(
            Unidad("Celsius", "°C", 1.0),
            Unidad("Fahrenheit", "°F", 1.0),
            Unidad("Kelvin", "K", 1.0)
        ), esTemperatura = true),
        Categoria("Volumen", listOf(
            Unidad("Litro", "L", 1.0),
            Unidad("Mililitro", "mL", 0.001),
            Unidad("Metro cúbico", "m³", 1000.0),
            Unidad("Galón (US)", "gal", 3.785411784),
            Unidad("Taza (US)", "cup", 0.2365882365),
            Unidad("Onza fluida (US)", "fl oz", 0.0295735295625)
        )),
        Categoria("Área", listOf(
            Unidad("Metro cuadrado", "m²", 1.0),
            Unidad("Kilómetro cuadrado", "km²", 1000000.0),
            Unidad("Hectárea", "ha", 10000.0),
            Unidad("Centímetro cuadrado", "cm²", 0.0001),
            Unidad("Pie cuadrado", "ft²", 0.09290304),
            Unidad("Acre", "ac", 4046.8564224),
            Unidad("Pulgada cuadrada", "in²", 0.00064516)
        )),
        Categoria("Velocidad", listOf(
            Unidad("Metro por segundo", "m/s", 1.0),
            Unidad("Kilómetro por hora", "km/h", 1.0 / 3.6),
            Unidad("Milla por hora", "mph", 0.44704),
            Unidad("Nudo", "kn", 1852.0 / 3600.0),
            Unidad("Pie por segundo", "ft/s", 0.3048)
        )),
        Categoria("Tiempo", listOf(
            Unidad("Segundo", "s", 1.0),
            Unidad("Milisegundo", "ms", 0.001),
            Unidad("Minuto", "min", 60.0),
            Unidad("Hora", "h", 3600.0),
            Unidad("Día", "d", 86400.0),
            Unidad("Semana", "sem", 604800.0)
        )),
        Categoria("Presión", listOf(
            Unidad("Pascal", "Pa", 1.0),
            Unidad("Kilopascal", "kPa", 1000.0),
            Unidad("Bar", "bar", 100000.0),
            Unidad("Atmósfera", "atm", 101325.0),
            Unidad("PSI", "psi", 6894.757293168),
            Unidad("mmHg", "mmHg", 133.322387415)
        )),
        Categoria("Energía", listOf(
            Unidad("Joule", "J", 1.0),
            Unidad("Kilojoule", "kJ", 1000.0),
            Unidad("Caloría", "cal", 4.184),
            Unidad("Kilocaloría", "kcal", 4184.0),
            Unidad("Kilovatio hora", "kWh", 3600000.0),
            Unidad("BTU", "BTU", 1055.05585262)
        )),
        Categoria("Datos", listOf(
            Unidad("Byte", "B", 1.0),
            Unidad("Bit", "bit", 0.125),
            Unidad("Kilobyte", "KB", 1024.0),
            Unidad("Megabyte", "MB", 1048576.0),
            Unidad("Gigabyte", "GB", 1073741824.0),
            Unidad("Terabyte", "TB", 1099511627776.0)
        ))
    )
}
